// ============================================================
// Biboswan Roy Portfolio — App
// ============================================================
const { useState, useEffect, useRef, useMemo, useCallback } = React;
const C = window.BR_CONTENT;

/* ---------- DEFAULTS (editable via Tweaks) ---------- */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "#dcff5b",
  "heroVariant": "kinetic",
  "typeDirection": "serif-display",
  "showCursor": true,
  "showMarquee": true
}/*EDITMODE-END*/;

/* ---------- Utils: scroll reveal ---------- */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

/* ---------- Nav ---------- */
function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [time, setTime] = useState("");
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const tick = () => {
      const d = new Date();
      const h = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Kolkata" });
      setTime(`IST · ${h}`);
    };
    tick();
    const t = setInterval(tick, 30000);
    return () => { window.removeEventListener("scroll", onScroll); clearInterval(t); };
  }, []);
  return (
    <nav className={"nav" + (scrolled ? " is-scrolled" : "")}>
      <a href="#top" className="brand" data-cursor="hover">
        <span className="brand-mark">{C.monogram}</span>
        <span>{C.shortName.toLowerCase()}.roy</span>
      </a>
      <div className="links">
        <a href="#work" data-cursor="hover">Work</a>
        <a href="#about" data-cursor="hover">About</a>
        <a href="#experience" data-cursor="hover">Experience</a>
        <a href="#events" data-cursor="hover">Events</a>
        <a href="#writing" data-cursor="hover">Writing</a>
        <a href="#contact" data-cursor="hover">Contact</a>
      </div>
      <div className="meta">
        <span className="status-dot" />
        <span>Available · Q3</span>
        <span style={{ opacity: 0.5 }}>·</span>
        <span>{time}</span>
      </div>
    </nav>
  );
}

/* ---------- Hero variants ---------- */
function HeroKinetic({ showMarquee }) {
  const [roleIdx, setRoleIdx] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setRoleIdx((i) => (i + 1) % C.roles.length), 2400);
    return () => clearInterval(id);
  }, []);
  return (
    <section id="top" className="hero wrap">
      <div className="hero-grid-bg" aria-hidden="true" />
      <div className="hero-top">
        <div className="col-meta">
          <span className="availability">
            <span className="status-dot" /> Open for select 2026 collaborations
          </span>
          <p className="intro-line">
            <b>{C.shortName} Roy</b> — Senior Software Engineer building enterprise security UI at SentinelOne. Remote-first, distributed-team friendly, 6 countries last year.
          </p>
        </div>
        <div style={{ alignSelf: "end", justifySelf: "end", textAlign: "right" }}>
          <span className="eyebrow">{C.location}</span>
        </div>
      </div>

      <h1 className="display hero-name" aria-label={C.name.join(" ")}>
        <span className="word"><span>{C.name[0]}</span></span>
        <span className="word">
          <span>{C.name[1]}<i className="accent-dot" /></span>
        </span>
      </h1>

      <div className="hero-bottom">
        <div className="role-rotator">
          <span className="static">currently a</span>
          <span className="rot-track" style={{ minWidth: "11ch" }}>
            {C.roles.map((r, i) => {
              let cls = "slot is-next";
              if (i === roleIdx) cls = "slot is-in";
              else if (i === (roleIdx - 1 + C.roles.length) % C.roles.length) cls = "slot is-out";
              return <span key={r} className={cls}>{r}</span>;
            })}
          </span>
        </div>
        <div className="hero-stat">
          <span className="label">Countries / year</span>
          <span className="value">{String(C.countriesLast).padStart(2, "0")}<small>+ since 2023</small></span>
        </div>
        <div className="hero-stat">
          <span className="label">Years shipping</span>
          <span className="value">{String(C.yearsExp).padStart(2, "0")}<small>frontend & full-stack-ish</small></span>
        </div>
      </div>

      {showMarquee && (
        <div className="hero-marquee" aria-hidden="true">
          <div className="track">
            {[...C.marquee, ...C.marquee].map((w, i) => (
              <span key={i}>{w}<i className="dot" /></span>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function HeroMonogram() {
  return (
    <section id="top" className="hero wrap" style={{ justifyContent: "center", textAlign: "center" }}>
      <div className="hero-grid-bg" aria-hidden="true" />
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 28 }}>
        <span className="eyebrow">Senior Software Engineer · India · Remote</span>
        <div
          className="display"
          style={{
            fontSize: "clamp(180px, 36vw, 520px)",
            lineHeight: 0.8,
            letterSpacing: "-0.06em",
            position: "relative",
          }}
        >
          B<span style={{ color: "var(--accent)" }}>R</span>
        </div>
        <h1 className="display" style={{ fontSize: "clamp(40px, 6vw, 84px)", margin: 0 }}>
          {C.name.join(" ")}
        </h1>
        <p className="intro-line" style={{ maxWidth: "44ch", margin: 0, textAlign: "center" }}>
          {C.intro}
        </p>
      </div>
    </section>
  );
}

function HeroAscii() {
  return (
    <section id="top" className="hero wrap">
      <div className="hero-top">
        <div className="col-meta">
          <span className="availability">
            <span className="status-dot" /> Open for select 2026 collaborations
          </span>
          <p className="intro-line"><b>{C.shortName} Roy</b> — Senior Software Engineer · enterprise security UI · digital nomad.</p>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 60, alignItems: "center", flex: 1 }}>
        <h1 className="display hero-name" style={{ fontSize: "clamp(64px, 14vw, 200px)" }}>
          <span className="word"><span>{C.name[0]}.</span></span>
          <span className="word"><span style={{ fontStyle: "italic", color: "var(--fg-muted)" }}>{C.name[1]}<i className="accent-dot" /></span></span>
        </h1>
        <pre style={{
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          lineHeight: 1.5,
          color: "var(--fg-muted)",
          margin: 0,
          whiteSpace: "pre",
          overflow: "hidden",
          borderLeft: "1px solid var(--border)",
          paddingLeft: 24,
        }}>{`> whoami
  biboswan.roy

> location
  in transit · 6 countries / year

> stack
  react · typescript · graphql
  next · node · go · python

> currently
  senior swe @ sentinelone
  building singularity platform

> previously
  feats.co · mozilla · studioyou
  iim lucknow · creatella

> credentials
  google udacity scholar '18
  mozillian · techstars nyc r1

> contact
  bibo@biboswanroy.com
`}</pre>
      </div>
    </section>
  );
}

/* ---------- About ---------- */
function About() {
  const renderRich = (text) => {
    // bold **text** + .hl
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((p, i) => {
      if (p.startsWith("**")) return <b key={i}>{p.slice(2, -2)}</b>;
      return <span key={i}>{p}</span>;
    });
  };
  return (
    <section id="about">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/01 — About</span>
          <h2>Words<br /><i style={{ color: "var(--fg-muted)" }}>about her</i></h2>
        </div>
        <div className="about-grid">
          <div className="label-col">
            <span className="eyebrow reveal">Bio · 2026</span>
          </div>
          <div className="about-bio reveal">
            {C.about.paragraphs.map((p, i) => (
              <p key={i} style={{ marginTop: i === 0 ? 0 : "1em" }}>{renderRich(p)}</p>
            ))}
          </div>
          <aside className="about-side reveal">
            <div className="kv">
              <span className="k">Based</span>
              <div className="v"><ul>{C.about.facts.based.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
            </div>
            <div className="kv">
              <span className="k">Stack</span>
              <div className="v"><ul>{C.about.facts.stack.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
            </div>
            <div className="kv">
              <span className="k">Recognised</span>
              <div className="v"><ul>{C.about.facts.open.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
            </div>
            <div className="kv">
              <span className="k">Working</span>
              <div className="v"><ul>{C.about.facts.mode.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

/* ---------- Work ---------- */
function Work() {
  return (
    <section id="work">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/02 — Selected work</span>
          <h2>Recent<br /><i style={{ color: "var(--fg-muted)" }}>shipping</i></h2>
        </div>
        <div className="work-list reveal">
          {C.projects.map((p) => {
            const hasLink = p.href && p.href !== "#";
            const Tag = hasLink ? "a" : "div";
            const linkProps = hasLink
              ? { href: p.href, target: "_blank", rel: "noreferrer" }
              : {};
            return (
              <Tag
                key={p.num}
                className="work-row"
                data-cursor="hover"
                {...linkProps}
              >
                <span className="num">{p.num}</span>
                <span className="title">{p.title}</span>
                <span className="client">{p.client}</span>
                <span className="tags">
                  {p.tags.map((t) => <span key={t} className="tag">{t}</span>)}
                </span>
                <span className="year">
                  {p.year}
                  {p.action && <span style={{ marginLeft: 10, opacity: 0.6 }}>· {p.action}</span>}
                  <span className="arrow"> {p.action === "Read" ? "→" : "↗"}</span>
                </span>
              </Tag>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- Companies ---------- */
function Companies() {
  return (
    <section id="companies">
      <div className="wrap">
        <div className="companies-head reveal">
          <span className="eyebrow">Trusted by · Worked with</span>
          <p>Drop your real logos into any slot — they persist.</p>
        </div>
        <div className="companies-grid reveal">
          {C.companies.map((co) => (
            <div key={co.name} className="company-card" data-cursor="hover">
              <image-slot
                id={"logo-" + co.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}
                shape="rect"
                fit="contain"
                placeholder=" "
                style={{ display: "block", width: "100%", height: "56px" }}
              ></image-slot>
              <div className="company-meta">
                <span className="company-name">{co.name}</span>
                <span className="company-note">{co.note}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Experience ---------- */
function Experience() {
  const slotId = (name) => "logo-" + name.toLowerCase().replace(/[^a-z0-9]/g, "-");
  return (
    <section id="experience">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/03 — Experience</span>
          <h2>Where<br /><i style={{ color: "var(--fg-muted)" }}>I have built</i></h2>
        </div>
        <div className="exp-list reveal">
          {C.experience.map((e, i) => (
            <div key={i} className="exp-row" data-cursor="hover">
              <div className="exp-logo">
                <image-slot
                  id={slotId(e.company)}
                  shape="rect"
                  fit="contain"
                  placeholder=" "
                  style={{ display: "block", width: "100%", height: "44px" }}
                ></image-slot>
              </div>
              <div className="company">{e.company}</div>
              <div className="role">{e.role}</div>
              <div className="period">{e.period}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Events ---------- */
function Events() {
  return (
    <section id="events">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/04 — Events</span>
          <h2>Talks &<br /><i style={{ color: "var(--fg-muted)" }}>appearances</i></h2>
        </div>
        <div className="list-tight reveal">
          {C.events.map((e, i) => (
            <a key={i} className="list-row" href="#" data-cursor="hover">
              <span className="list-date">{e.date}</span>
              <span className="list-kind">{e.kind}</span>
              <span className="list-title">{e.title}</span>
              <span className="list-venue">{e.venue}</span>
              <span className="list-arr">↗</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Writing ---------- */
function Writing() {
  return (
    <section id="writing">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/05 — Writing</span>
          <h2>From the<br /><i style={{ color: "var(--fg-muted)" }}>notebook</i></h2>
        </div>
        <div className="list-tight reveal">
          {C.writing.map((w, i) => (
            <a key={i} className="list-row" href="#" data-cursor="hover">
              <span className="list-date">{w.date}</span>
              <span className="list-kind">{w.read}</span>
              <span className="list-title">{w.title}</span>
              <span className="list-venue">{w.venue}</span>
              <span className="list-arr">→</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Testimonials ---------- */
function Quotes() {
  return (
    <section id="quotes">
      <div className="wrap">
        <div className="section-head reveal">
          <span className="section-num">/06 — Kind words</span>
          <h2>People<br /><i style={{ color: "var(--fg-muted)" }}>I have worked with</i></h2>
        </div>
        <div className="quotes reveal">
          {C.testimonials.map((q, i) => (
            <article key={i} className="quote-card">
              <div className="quote-mark">“</div>
              <div className="quote-body">{q.body}</div>
              <div className="quote-author">
                <span className="name">{q.name}</span>
                <span className="role">{q.role}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Contact ---------- */
function Contact() {
  return (
    <section id="contact">
      <div className="wrap">
        <div className="contact reveal">
          <div>
            <span className="section-num">/07 — Say hello</span>
          </div>
          <div>
            <div className="contact-big">
              Let's build<br />
              <span style={{ fontStyle: "italic", color: "var(--fg-muted)" }}>something</span><br />
              <a href="mailto:bibo@biboswanroy.com" data-cursor="hover">together.</a>
            </div>
            <p className="contact-sub">
              Always up for distributed-team work, interesting frontend architectures, or a slow coffee in whichever city I'm in this month.
            </p>
            <div className="contact-side" style={{ marginTop: 48, maxWidth: 480 }}>
              {C.socials.map((s) => (
                <a key={s.label} href={s.href} target="_blank" rel="noreferrer" data-cursor="hover">
                  <span>{s.label.toUpperCase()} · {s.value}</span>
                  <span className="arr">↗</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Cursor ---------- */
function Cursor({ enabled }) {
  const ref = useRef(null);
  const [hov, setHov] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    const el = ref.current;
    if (!el) return;
    let raf = null;
    let x = window.innerWidth / 2, y = window.innerHeight / 2;
    let tx = x, ty = y;
    const move = (e) => { tx = e.clientX; ty = e.clientY; };
    const tick = () => {
      x += (tx - x) * 0.22;
      y += (ty - y) * 0.22;
      el.style.left = x + "px";
      el.style.top  = y + "px";
      raf = requestAnimationFrame(tick);
    };
    const over = (e) => {
      const t = e.target.closest("[data-cursor='hover'], a, button");
      setHov(!!t);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", over);
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", over);
      cancelAnimationFrame(raf);
    };
  }, [enabled]);
  if (!enabled) return null;
  return <div ref={ref} className={"cursor" + (hov ? " is-hover" : "")} />;
}

/* ---------- Tweaks ---------- */
const ACCENT_SWATCHES = ["#dcff5b", "#ff5b2e", "#5b8def", "#e8e6df", "#c084fc"];

function TweaksUI({ t, setTweak }) {
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Theme">
        <TweakRadio
          label="Mode"
          value={t.theme}
          onChange={(v) => setTweak("theme", v)}
          options={[{ label: "Dark", value: "dark" }, { label: "Light", value: "light" }]}
        />
        <TweakColor
          label="Accent"
          value={t.accent}
          onChange={(v) => setTweak("accent", v)}
          options={ACCENT_SWATCHES}
        />
      </TweakSection>
      <TweakSection label="Hero">
        <TweakSelect
          label="Variant"
          value={t.heroVariant}
          onChange={(v) => setTweak("heroVariant", v)}
          options={[
            { label: "Kinetic name (default)", value: "kinetic" },
            { label: "Big monogram BR", value: "monogram" },
            { label: "Typographic + terminal", value: "ascii" },
          ]}
        />
        <TweakToggle
          label="Skill marquee"
          value={t.showMarquee}
          onChange={(v) => setTweak("showMarquee", v)}
        />
      </TweakSection>
      <TweakSection label="Type">
        <TweakRadio
          label="Display"
          value={t.typeDirection}
          onChange={(v) => setTweak("typeDirection", v)}
          options={[
            { label: "Serif", value: "serif-display" },
            { label: "Sans", value: "sans-display" },
          ]}
        />
      </TweakSection>
      <TweakSection label="Cursor">
        <TweakToggle
          label="Custom cursor"
          value={t.showCursor}
          onChange={(v) => setTweak("showCursor", v)}
        />
      </TweakSection>
    </TweaksPanel>
  );
}

/* ---------- App ---------- */
function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  useReveal();

  // apply tweaks to :root
  useEffect(() => {
    const r = document.documentElement;
    r.setAttribute("data-theme", tweaks.theme);
    r.style.setProperty("--accent", tweaks.accent);
    if (tweaks.typeDirection === "sans-display") {
      r.style.setProperty("--font-display", '"Geist", "Helvetica Neue", sans-serif');
    } else {
      r.style.setProperty("--font-display", '"Instrument Serif", "Times New Roman", serif');
    }
  }, [tweaks.theme, tweaks.accent, tweaks.typeDirection]);

  const Hero = useMemo(() => {
    if (tweaks.heroVariant === "monogram") return <HeroMonogram />;
    if (tweaks.heroVariant === "ascii") return <HeroAscii />;
    return <HeroKinetic showMarquee={tweaks.showMarquee} />;
  }, [tweaks.heroVariant, tweaks.showMarquee]);

  return (
    <React.Fragment>
      <Cursor enabled={tweaks.showCursor} />
      <Nav />
      {Hero}
      <About />
      <Work />
      <Experience />
      <Events />
      <Writing />
      <Quotes />
      <Contact />
      <footer className="footer">
        <span>© Biboswan Roy · 2026</span>
        <span className="br-mark">BR.</span>
        <span>Built with intention · not a template</span>
      </footer>
      <TweaksUI t={tweaks} setTweak={setTweak} />
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
